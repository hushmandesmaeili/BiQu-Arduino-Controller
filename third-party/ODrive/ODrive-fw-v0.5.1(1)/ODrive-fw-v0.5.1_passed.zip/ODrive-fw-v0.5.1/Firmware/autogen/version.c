const unsigned char fw_version_major_ = 0;
const unsigned char fw_version_minor_ = 0;
const unsigned char fw_version_revision_ = 0;
const unsigned char fw_version_unreleased_ = 1;
